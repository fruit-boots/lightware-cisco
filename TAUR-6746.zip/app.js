#!/usr/bin/nodejs
Config = require('./config').Config;
Shared = Config.Shared;
Codec = Config.Devices.Codec;
Lightware = Config.Devices.Lightware;

let RoomList = {};
try {
	RoomList = require('./roomlist.json');
} catch(err) {
	console.log(`  == > !!! RoomList ERROR: roomlist.json cannot be loaded.`,err);
}

lw3client = require('./lw3client');
const RoomQuerier =  require('./roomquerier');
roomquerier = new RoomQuerier(RoomList);
const jsxapi = require('jsxapi');

var presentationSelectedXPState = [null, null];
var PresentationMode = false;
var InCall = false;
var SignalStates_on_AllocatedConnectorIds = [];
var ExitPresentationTimer;
var ExitPresentationNotifier;
var SourceNotifier;
var wsconnecttimeout=null;
var PreviousSelectedCameraPreset = "Webex";
var WebcamSources = [];

Shared.ExternalSourceList.map( (item) => item.switch = function() {
	console.log(`  == > UserInterface Presentation ExternalSource Selected SourceIdentifier: "${item.SourceIdentifier}"`);
	dev.lw3.CALL(`/V1/MEDIA/VIDEO/XP:switch`, `I${item.Input}:O${Lightware.Output}`, () => {});
	console.log(`  == > CALL /V1/MEDIA/VIDEO/XP:switch(I${item.Input}:O${Lightware.Output})`);

	/* use when USB switch required paralelly with video switch */
	//dev.lw3.CALL(`/V1/MEDIA/USB/XP:switch`, `U${item.Input}:H1`, () => {});
});

function updateCodecExternalSourceState(item) {
	if (Codec.isConnected) {
		Codec.xAPI.command('UserInterface Presentation ExternalSource State Set', {SourceIdentifier:item.SourceIdentifier, State:item.State}).then( response => {
			if(response.status=='OK') {	console.log(`  == > SourceIdentifier:"${item.SourceIdentifier}" is ${item.State}`);	}
			else { console.log(`  == > Respond in not OK for SourceIdentifier:"${item.SourceIdentifier}" status update`); }
		});
	} else {console.log(`  == > Codec is not connected SourceIdentifier:"${item.SourceIdentifier}" will not be updated.`);}
}

function updateCodecUSBConnected(item) {
	if (Codec.isConnected) {
		Codec.xAPI.command('Message Send', {Text: item.Name + ' USB plugged in'}).then( response => {
			if(response.status=='OK') {	console.log(`  == > Message to Codec: Message Send Text: "${item.Name + ' USB plugged in'}" is`);	}
			else { console.log(`  == > Message not sent to Codec:"${item.Name + ' USB plugged in'}"`); }
		});
	} else {console.log(`  == > Codec is not connected, message not sent to Codec:"${item.Name + " USB plugged in"}"`);}	
}

function registerSignalPresent(item, index) {
	dev.lw3.addPropertyeWatcher(`/V1/MEDIA/VIDEO/I${item.Input}.SignalPresent`, (val) => {
		console.log(`  == > /V1/MEDIA/VIDEO/I${item.Input}.SignalPresent=${val}`);
		item.State = ((/true|1/).test(val)==true) ? "Ready":"NotReady";
		updateCodecExternalSourceState(item);
	});
	console.log(`  == > LW3 property watcher registred for ${item.Name} for IN${item.Input}`);
}

function registerUSBConnectionWatchers(item, index) {
	dev.lw3.addPropertyeWatcher(`/V1/MEDIA/USB/U${item.Input}.Connected`, (val) => {
		console.log(`  == > /V1/MEDIA/VIDEO/U${item.Input}.Connected=${val}`);
		//item.State = ((/true|1/).test(val)==true) ? "Ready":"NotReady";

		if((/true|1/).test(val) === true){
			updateCodecUSBConnected(item);
		}
	});
	console.log(`  == > LW3 property watcher registred for ${item.Name} for IN${item.Input}`);
}

function registerExternalSources(item, index) {
	if (Codec.isConnected) {
		Codec.xAPI.command('UserInterface Presentation ExternalSource Add', {ConnectorId:Codec.ConnectorId, Name:item.Name, SourceIdentifier:item.SourceIdentifier, Type:item.Type}).then( response => {
			if(response.status=='OK') { console.log(`  == > ${item.Name} added to the Share screen elements with SourceIdentifier:"${item.SourceIdentifier}"`); }
			else { console.log(`  == > Respond in not OK for SourceIdentifier:"${item.SourceIdentifier}" addition`); }
		});
	}
	updateCodecExternalSourceState(item);
}

let CiscoCodecOutputCount = 0;
const dev = lw3client.Noodle({'log': false});
Codec.Room = undefined;

function initRoom(ip) {
	Codec.Room = roomquerier.findRoomByDevice(Lightware.ID, ip);
	if(Codec.Room == undefined) {
		console.log(`  == > !!! No room found in the room list for my IP address or host name: `,ip); 
		return;
	}
	console.log(`  == > Room found in the room list for my IP address or host name: `,Codec.Room); 
	
	Codec.IPAddress = Codec.Room.get(Codec.ID);
	console.log('Codec.IPAddress',Codec.IPAddress);
	if(Codec.IPAddress == undefined) {
		console.log(`  == > !!! No codec ip address found in the room list for `,Codec.ID); 
		return;
	}
	console.log(`  == > Codec ip address found in the room list for `,Codec.IPAddress);

	jsxapi
	.connect("wss://"+Codec.IPAddress, {
		username: Codec.UserName,
		password: Codec.Password,
	})
	.on('close', (err) => {errorCodec(err);})
	.on('error', (err) => {errorCodec(err);})
	.on('ready', (xapi) => {
		Codec.xAPI = xapi;
		xapi.backend.isReady.then( (xapi) => {
			readyCodec(xapi);
		})
		.catch((reason) => {
			console.log('isReady catched: ',reason);
		});
	});
}

/* Register to input signal changes */
Shared.ExternalSourceList.forEach(registerSignalPresent);
//Shared.ExternalSourceList.forEach(registerUSBConnectionWatchers);
dev.lw3.addPropertyeWatcher(`/V1/MANAGEMENT/UID.HwVersion`, (val) => { Lightware.HwVersion = val; });
dev.lw3.addPropertyeWatcher(`/.PackageVersion`, (val) => { Lightware.PackageVersion = val; });
dev.lw3.addPropertyeWatcher(`/.ProductName`, (val) => { Lightware.ProductName = val; });
dev.lw3.addPropertyeWatcher(`/V1/MANAGEMENT/NETWORK.IpAddress`,  (val) => { Lightware.IpAddress = val; if(!Codec.Room) initRoom(val); });
dev.lw3.addPropertyeWatcher(`/V1/MANAGEMENT/NETWORK.HostName`, (val) => { Lightware.HostName = val; if(!Codec.Room) initRoom(val); if(!Codec.Room) initRoom(`${val}.local`); });
dev.lw3.addPropertyeWatcher(`/.SerialNumber`, (val) => { Lightware.SerialNumber = val; });

function readyCodec() {
	console.log('  == > Cisco Codec conenction ready');

	Codec.isConnected = true;

	Codec.xAPI.config.get('Video Input Connector').then( response => {
		/* set ut the used connector */
		response.filter( connector => connector.id == Codec.ConnectorId).map( c => {
			Codec.xAPI.config.set(`Video Input Connector ${c.id} Name`,'Source');
			Codec.xAPI.config.set(`Video Input Connector ${c.id} Visibility`,'Always');
			if (c.InputSourceType != 'camera') {
				Codec.xAPI.config.set(`Video Input Connector ${c.id} PresentationSelection`,'Manual');
				Codec.xAPI.config.set(`Video Input Connector ${c.id} CameraControl Mode`,'Off');
			}
		});
		/* setup the unused connector */
		response.filter( connector => connector.id != Codec.ConnectorId).map( c => {
			Codec.xAPI.config.set(`Video Input Connector ${c.id} Name`,'');
			Codec.xAPI.config.set(`Video Input Connector ${c.id} Visibility`,'Never');
		});
	});

	Codec.xAPI.config.get('Video Output Connector').then( response => {
		CiscoCodecOutputCount = response.length;
	});

	/* Control system and heartbeat handling */
	Codec.xAPI.config.set(`Peripherals Profile ControlSystems`,1).then( result => {
		console.log(`  == > Peripherals Profile ControlSystems 1 resulted ${result.status}`);
	});
	Codec.xAPI.command(`Peripherals Connect`,
		{
			ID: 'Lightware',
			Name:`Lightware ${Lightware.ProductName}`,
			Type:'ControlSystem',
			SerialNumber:Lightware.SerialNumber,
			NetworkAddress:Lightware.IpAddress,
			HardwareInfo:Lightware.HwVersion,
			SoftwareInfo:Lightware.PackageVersion
		}).then( result => {
		console.log(`  == > Lightware Taurus registered as ControlSystem resulted ${result.status}`);
	});
	Codec.xAPI.command(`Peripherals HeartBeat`,{ID: 'Lightware', Timeout:10}).then( result => {
		//console.log(`  == > HeartBeat update ${result.status}`);
	});
	Shared.HeartBeat = setInterval(
		function(){
			Codec.xAPI.command(`Peripherals HeartBeat`,{ID: 'Lightware', Timeout:10}).then( result => {
				//console.log(`  == > HeartBeat update ${result.status}`);
			});
		},
		10*60*10
	);

	/* Remove all the external sources from the Share screen */
	console.log('  == > UserInterface Presentation ExternalSource RemoveAll');
	Codec.xAPI.command('UserInterface Presentation ExternalSource RemoveAll').then( response => {
		if(response.status=='OK') {	console.log(`  == > Removing all ExternalSources from the Share screen succeeded`);	}
		else { console.log(`  == > Respond in not OK for ExternalSources removal`);	}
	});

	/* Register the configured sources to the codec, and update the signal info */
	Shared.ExternalSourceList.forEach(registerExternalSources);

	/* Switch source when selected */
	Codec.xAPI.event.on('UserInterface Presentation ExternalSource Selected SourceIdentifier', (selectedsourceid) => {
		Shared.ExternalSourceList.find( (item) => item.SourceIdentifier == selectedsourceid ).switch();
	});
	Codec.xAPI.event.on('PresentationStopped',		(event) => { Shared.PresentationStopped(event, dev); });
	Codec.xAPI.event.on('PresentationPreviewStopped',	(event) => { Shared.PresentationStopped(event, dev); });
	Codec.xAPI.event.on('PresentationStarted',		(event) => { Shared.PresentationStarted(event, dev); });
	Codec.xAPI.event.on('PresentationPreviewStarted',	(event) => { Shared.PresentationStarted(event, dev); });
	
	Codec.xAPI.event.on('OutgoingCallIndication',		(event) => { Shared.CallStarted(event, dev); });
	Codec.xAPI.event.on('IncomingCallIndication',		(event) => { Shared.CallStarted(event, dev); });
	Codec.xAPI.event.on('CallDisconnect',				(event) => { Shared.CallEnded(event, dev); });
	
//	Codec.xAPI.command(`UserInterface Message Prompt Display`,{Title: `Lightware ${Lightware.ProductName} integration to ${Codec.Room.roomID}`, Text:'Your system is ready to use', Duration:5});
	Codec.xAPI.command(`UserInterface Message Prompt Display`,{Text: `Room ${Codec.Room.roomID}<br>integrated with<br>Lightware ${Lightware.ProductName}`, Title:'Your system is ready to use', Duration:10});
	Codec.xAPI.command(`Presentation Stop`,{}).then( response => {
		Shared.PresentationStopped(null, dev);
	});


	for(var i = 1; i <= 4; i++){
		WebcamSources[i-1] = "";

		Shared.ExternalSourceList.forEach((item) => {
			if(i == parseInt(item.Input, 10)){
				WebcamSources[i-1] = item.Name;
			}
		});
	}

	var WebcamMode = `
	<Extensions>
		<Version>1.6</Version>
		<Panel>
			<PanelId>ucmodeselector</PanelId>
			<Type>Home</Type>
			<Icon>Input</Icon>
			<Order>4</Order>
			<Color>#9d0b0e</Color>
			<Name>BYOD Selection</Name>
			<ActivityType>Custom</ActivityType>
			<Page>
				<Name>BYOD Selection</Name>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>info</WidgetId>
						<Type>Text</Type>
						<Options>size=3;fontSize=small;align=center</Options>
						<Name>Connect your source via USB to enable   Webcam + Speaker + Microphone   via USB connection</Name>
					</Widget>
				</Row>
				<Row>
					<Name></Name>
					<Widget>
					<WidgetId>webcamselector</WidgetId>
					<Type>GroupButton</Type>
					<Options>size=4;columns=1</Options>
					<ValueSpace>
						${WebcamSources.map( (ws,i) => (ws!='') ? '<Value><Key>'+(i+1)+'</Key><Name>'+ws+' USB</Name></Value>' : '')}
						<Value>
							<Key>Webex</Key>
							<Name>Webex</Name>
						</Value>
					</ValueSpace>
					</Widget>
				</Row>
				<Row>
					<Name></Name>
					<Widget>
					<WidgetId>exit</WidgetId>
					<Type>Text</Type>
					<Options>size=3;fontSize=small;align=center</Options>
					<Name>Tap outside of the page to close page</Name>
					</Widget>
				</Row>
				<Options>hideRowNames=1</Options>
			</Page>
		</Panel>
	</Extensions>`;

	Codec.xAPI.command('UserInterface Extensions Panel Save', {PanelId: 'ucmodeselector' }, WebcamMode);

	var PresentationPanel = `
	<Extensions>
		<Version>1.5</Version>
		<Panel>
			<Name>Presentation</Name>
			<PanelId>lw-presentation</PanelId>
			<Icon>Tv</Icon>
			<Color>#2e3848</Color>
			<Type>Home</Type>
			<Order>2</Order>
			<Page>
				<Name>Display 1</Name>
				<PageId>cisco-lwpresentation1</PageId>
				<Options>hideRowNames=1</Options>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>lwcisco-out1-lw</WidgetId>
						<Type>GroupButton</Type>
						<ValueSpace>
						<Value>
							<Name>USB-C 1</Name>
							<Key>I1:O1 Output:1 SId:2</Key>
						</Value>
						<Value>
							<Name>USB-C 2</Name>
							<Key>I2:O1 Output:1 SId:2</Key>
						</Value>
						<Value>
							<Name>HDMI 3</Name>
							<Key>I3:O1 Output:1 SId:2</Key>
						</Value>
						<Value>
							<Name>HDMI 4</Name>
							<Key>I4:O1 Output:1 SId:2</Key>
						</Value>
						</ValueSpace>
						<Options>size=4;columns=1</Options>
					</Widget>
				</Row>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>exit-presentation</WidgetId>
						<Type>Button</Type>
						<Name>Exit Presentation</Name>
					</Widget>
				</Row>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>close-page</WidgetId>
						<Type>Text</Type>
						<Name>Tap outside of the page to close page</Name>
						<Options>size=3;fontSize=small;align=center</Options>
					</Widget>
				</Row>
			</Page>
			<Page>
				<Name>Display 2</Name>
				<PageId>cisco-lwpresentation2</PageId>
				<Options>hideRowNames=1</Options>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>lwcisco-out2-lw</WidgetId>
						<Type>GroupButton</Type>
						<ValueSpace>
						<Value>
							<Name>USB-C 1</Name>
							<Key>I1:O2 Output:2 SId:3</Key>
						</Value>
						<Value>
							<Name>USB-C 2</Name>
							<Key>I2:O2 Output:2 SId:3</Key>
						</Value>
						<Value>
							<Name>HDMI 3</Name>
							<Key>I3:O2 Output:2 SId:3</Key>
						</Value>
						<Value>
							<Name>HDMI 4</Name>
							<Key>I4:O2 Output:2 SId:3</Key>
						</Value>
						</ValueSpace>
						<Options>size=4;columns=1</Options>
					</Widget>
				</Row>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>exit-presentation</WidgetId>
						<Type>Button</Type>
						<Name>Exit Presentation</Name>
					</Widget>
				</Row>
				<Row>
					<Name></Name>
					<Widget>
						<WidgetId>close-page</WidgetId>
						<Type>Text</Type>
						<Name>Tap outside of the page to close page</Name>
						<Options>size=3;fontSize=small;align=center</Options>
					</Widget>
				</Row>
			</Page>
		</Panel>
	</Extensions>
	`

	Codec.xAPI.command('UserInterface Extensions Panel Save', {PanelId: 'lw-presentation' }, PresentationPanel);

	Codec.xAPI.event.on('UserInterface Message Prompt Response', (event) => {
		for (var cam in WebcamSources) {
			if (event.FeedbackId == 'SwitchWebcam'+WebcamSources[cam]) {
				if (event.OptionId == '1') {
					Codec.xAPI.command('UserInterface Extensions Widget Action', {WidgetId: 'webcamselector', Value:Number(cam)+1, Type:'pressed'});
				}
			}
		}
	});


	for(let i = 1; i < 5; i++){
		dev.lw3.addPropertyeWatcher(`/V1/MEDIA/USB/U${i}.Connected`, (state)=>{
			USBConnectedStateChanged(i, state);
		});
	}


	Codec.xAPI.event.on('UserInterface Extensions Widget Action', (event) => {
		if ((event.WidgetId == 'webcamselector') && (event.Type == 'pressed')) {
			if (event.Value == 'Webex') {
				dev.lw3.CALL(`/V1/MEDIA/USB/XP:switch`, `0:H1`, () => {});
				dev.lw3.SET(`/V1/MEDIA/USB/H1/D1.Power5VMode`, `On`, () => {});

				Codec.xAPI.command('Presentation Stop');
				Codec.xAPI.config.set(`Video Input Connector ${Codec.ConnectorId} Visibility`, 'Always');
				Codec.xAPI.config.set('UserInterface Features Share Start', 'Auto');
				Codec.xAPI.config.set('UserInterface Features HideAll', 'False');
				Codec.xAPI.command('Conference DoNotDisturb Deactivate');
				Codec.xAPI.command('Video Matrix Reset');
				Codec.xAPI.config.set(`Audio Input HDMI ${Codec.ConnectorId} VideoAssociation MuteOnInactiveVideo`, 'On');
				Codec.xAPI.config.set('Audio Output Line 1 Mode', 'Off');
				Codec.xAPI.command('UserInterface Extensions Panel Update', {PanelId: 'ucmodeselector', Name: `BYOD Selection (Webex)`});
				Codec.xAPI.config.set('Standby Control', 'On');
				Codec.xAPI.command('Audio VuMeter Stop', {ConnectorType: 'Microphone', ConnectorId:2});

				ExitPresentationMode(InCall ? "INCALL" : "OUTOFCALL");


			} else {
				var input = event.Value;

				dev.lw3.CALL(`/V1/MEDIA/VIDEO/XP:switch`, `I${input}:O${Lightware.Output}`, () => {});
				dev.lw3.CALL(`/V1/MEDIA/USB/XP:switch`, `U${input}:H1`, () => {});
				dev.lw3.SET(`/V1/MEDIA/USB/H1/D1.Power5VMode`, `On`, () => {});

				Codec.xAPI.command('Presentation Stop');
				Codec.xAPI.config.set(`Video Input Connector ${Codec.ConnectorId} Visibility`, 'Never');
				Codec.xAPI.config.set('UserInterface Features Share Start', 'Hidden');
				Codec.xAPI.config.set('UserInterface Features HideAll', 'True');
				Codec.xAPI.command('Conference DoNotDisturb Activate');
				Codec.xAPI.command('Video Matrix Reset').then( (result) => {
					Codec.xAPI.command('Video Matrix Assign', {Mode: 'Replace', SourceId: Codec.ConnectorId, Output: 1}); /* Laptop signal to display 1 */
					//Codec.xAPI.command('Video Matrix Assign', {Mode: 'Replace', SourceId: 1, Output: CiscoCodecOutputCount}); /* Camera signal to USB capture */
					Codec.xAPI.command('Video Matrix Assign', {Mode: 'Replace', SourceId: Codec.ConnectorId, Output: 2}); /* Laptop signal to display 2 */
				});

				Codec.xAPI.config.set(`Audio Input HDMI ${Codec.ConnectorId} VideoAssociation MuteOnInactiveVideo`, 'Off');
				Codec.xAPI.config.set('Audio Output Line 1 Mode', 'On');
				Codec.xAPI.config.set('Audio Output Line 1 OutputType', 'Microphone');
				Codec.xAPI.command('UserInterface Extensions Panel Update', {PanelId: 'ucmodeselector', Name: `BYOD Selection (${WebcamSources[Number(event.Value)-1]} USB)`});
				Codec.xAPI.config.set('Standby Control', 'Off');
				Codec.xAPI.command('Audio VuMeter Start', {ConnectorType: 'Microphone', ConnectorId:2});
			}
			PreviousSelectedCameraPreset = event.Value;
		}

		if ((event.WidgetId == 'lwcisco-out1-lw') && (event.Type == 'pressed')) {
			console.log(`Lwcisco-out1-lw pressed: ${event.Value}`);
			if(/^I[0-9]{1}:O[0-9]{1}/.test(event.Value)){
				PresentationMode = true;
				console.log(`Switching video on Taurus: ${event.Value.substr(0, 5)}`);
				let switchParts = event.Value.match(/I[0-9]{1}:O[0-9]{1}/)[0];
				presentationSelectedXPState[0] = event.Value;
				dev.lw3.CALL(`/V1/MEDIA/VIDEO/XP:switch`, switchParts, () => {});

				// Input 2 to Output 1 on Codec
				Codec.xAPI.command('Video Matrix Assign', {Mode: 'Replace', SourceId: 2, Output: 1});
			}
		}

		if ((event.WidgetId == 'lwcisco-out2-lw') && (event.Type == 'pressed')) {
			console.log(`Lwcisco-out2-lw pressed: ${event.Value}`);
			if(/^I[0-9]{1}:O[0-9]{1}/.test(event.Value)){
				PresentationMode = true;
				console.log(`Switching video on Taurus: ${event.Value.substr(0, 5)}`);
				let switchParts = event.Value.match(/I[0-9]{1}:O[0-9]{1}/)[0];
				presentationSelectedXPState[1] = event.Value;
				dev.lw3.CALL(`/V1/MEDIA/VIDEO/XP:switch`, switchParts, () => {});

				// Input 3 to Output 2 on Codec
				Codec.xAPI.command('Video Matrix Assign', {Mode: 'Replace', SourceId: 3, Output: 2});
			}
		}

		if ((event.WidgetId == 'exit-presentation') && (event.Type == 'pressed')) {
			// TODO check
			// What is the desired operation here?
			PresentationMode = false;
			CloseVideoSignalNotifier();
			Codec.xAPI.command('UserInterface Extensions Panel Update', { PanelId: "lw-presentation", Name: "Presentation" });
			Codec.xAPI.command('UserInterface Extensions Panel Close');
			Codec.xAPI.command('Video Matrix Reset');
			Codec.xAPI.config.set('Standby Control', 'On');
			if (InCall) {
				// auto presenting xapi.command('Presentation Start', {ConnectorId: LightwareConfiguration.AllocatedConnectorIds[LightwareConfiguration.AllocatedConnectorIds.length-1]});
			} else {
				setTimeout(function(){ Codec.xAPI.command('Presentation Stop'); },500);
			}
		}
	});

	Codec.xAPI.event.on('UserInterface Extensions Panel Clicked', (event) => {
		if (event.PanelId == 'lw-presentation') {
		  SignalStates_on_AllocatedConnectorIds.map( c => Codec.xAPI.config.set(`Video Input Connector ${c.ConnectorId} Visibility`, 'Never'));
		  if (PresentationMode == false) {
			Codec.xAPI.command('UserInterface Extensions Panel Update', {PanelId: "lw-presentation", Name: "Presentation Presenting"});

			// Restore previous crosspoint state
			if(presentationSelectedXPState[0] !== null){
				Codec.xAPI.command('UserInterface Extensions Widget SetValue', { WidgetId: 'lwcisco-out1-lw', Value: presentationSelectedXPState[0] });
				Codec.xAPI.command('Video Matrix Assign', { Mode: 'Replace', Layout: 'Equal', Output: 1, SourceId: 2 });
				Codec.xAPI.command('UserInterface Extensions Widget Action', {Type:'pressed', WidgetId: 'lwcisco-out1-lw', Value: presentationSelectedXPState[0] });
			}

			if(presentationSelectedXPState[1] !== null){
				Codec.xAPI.command('UserInterface Extensions Widget SetValue', { WidgetId: 'lwcisco-out2-lw', Value: presentationSelectedXPState[1] });
				Codec.xAPI.command('Video Matrix Assign', { Mode: 'Replace', Layout: 'Equal', Output: 2, SourceId: 3 });
				Codec.xAPI.command('UserInterface Extensions Widget Action', {Type:'pressed', WidgetId: 'lwcisco-out2-lw', Value: presentationSelectedXPState[1] });
			}

			//setTimeout(function(){xapi.command('Message Send',{Text:'Lightware Unmute Signal'});},umt*500);
			SignalStates_on_AllocatedConnectorIds.map( c => Codec.xAPI.status.get(`Video Input Connector ${c.ConnectorId}`).then( (response) => { SignalUpdate(response); }));
			Codec.xAPI.config.set('Standby Control','Off');
			PresentationMode = true;
		  }
		}
	});

	Codec.xAPI.status.on('Standby State', (response) => { if (response == 'Off') { Codec.xAPI.command('UserInterface Extensions Widget Action', {WidgetId: 'webcamselector', Value:'Webex', Type:'pressed' }); }});
	Codec.xAPI.command('UserInterface Extensions Widget Action', {WidgetId: 'webcamselector', Value:'Webex', Type:'pressed' });

	Codec.xAPI.status.on('Standby State', (event) => { InCall = false; Codec.xAPI.config.set('Standby Control','On'); ExitPresentationMode('OUTOFCALL');});
	Codec.xAPI.event.on('OutgoingCallIndication', (event) => { InCall = true; ExitPresentationMode('INCALL');});
	Codec.xAPI.event.on('IncomingCallIndication', (event) => { InCall = true; ExitPresentationMode('INCALL');});
	Codec.xAPI.event.on('CallDisconnect', (event) => { InCall = false; ExitPresentationMode('OUTOFCALL');});

	Codec.xAPI.command('UserInterface Extensions List').then( result => {
		result.Extensions.Panel.map( p => p.Page.map( pg => pg.Row.map( r => r.Widget.filter( w => (!!w.ValueSpace)).map( w => Codec.xAPI.command('UserInterface Extensions Widget UnsetValue', {WidgetId: w.WidgetId})))));
		result.Extensions.Panel.map( p => p.Page.map( pg => pg.Row.map( r => r.Widget.filter( w => (!!w.ValueSpace)).map( w => {
		  var _Output = w.ValueSpace.Value[0].Key.match(/Output:(\d*)/);
		  var _SourceId = w.ValueSpace.Value[0].Key.match(/SId:(\d*)/);
		  var _ID = w.WidgetId.match(/^(lw|lwcisco)-out(\d*)-lw$/);
		  if ((_ID !== null) && (_ID[1] == 'lwcisco') && (_Output !== null) && (_SourceId !== null)) {
			SignalStates_on_AllocatedConnectorIds.push({ConnectorId: _SourceId[1], SignalState: false});
			console.log(`ConnectorId: ${_SourceId[1]} registered to VideoSignalNotifier`);
		  }
		}))));
		SignalStates_on_AllocatedConnectorIds.map( c => Codec.xAPI.status.get(`Video Input Connector ${c.ConnectorId}`).then( (response) => {SignalUpdate(response);}));
		SignalStates_on_AllocatedConnectorIds.map( c => Codec.xAPI.status.on(`Video Input Connector ${c.ConnectorId}`, (response) => {SignalUpdate(response);}));
	
	});
}

function SignalUpdate(response) {
	SignalStates_on_AllocatedConnectorIds.filter( r => r.ConnectorId == Number(response.id))[0].SignalState = response.SignalState;
	VideoSignalNotifier();
}

function VideoSignalNotifier(state) {
	if (SignalStates_on_AllocatedConnectorIds.filter(r => r.SignalState == 'OK').length == 0) {
	  if (PresentationMode == true) {
		CloseVideoSignalNotifier();
		SourceNotifier = setTimeout(function() { Codec.xAPI.command('UserInterface Message Prompt Display',{Title:'Presentation Mode', Text:'Previously selected sources seems to be disconnected.<br>Select from sources to display.', Duration:10}); }, 10000);
		ExitPresentationNotifier = setTimeout(function() {
			Codec.xAPI.command('UserInterface Message Prompt Display',{Title:'Presentation Mode', Text:'Previously selected sources seems to be disconnected.<br>Presentation Mode will be closed in 10 seconds.', Duration:10});
		}, 30000);
		ExitPresentationTimer = setTimeout(function() { InCall = false; ExitPresentationMode('OUTOFCALL'); }, 40000);
	  }
	  return;
	}
	Codec.xAPI.command('UserInterface Message Prompt Clear');
	CloseVideoSignalNotifier();
}

function ExitPresentationMode(mode) {
	Codec.xAPI.command('UserInterface Extensions Widget Action',{WidgetId:'exit-presentation', Type:'pressed'});
	// This will be always false
	//if(LightwareConfiguration.ShareScreenMenuEnabledOOC) {mode = 'Standard';}

	switch(mode) {
	  case 'Standard':
	  case 'INCALL':
		Codec.xAPI.config.set('UserInterface Features Share Start', 'Auto');
		Codec.xAPI.config.set(`Video Input Connector ${Codec.HDCPCapableConnectorId} HDCP Mode`,'Off');
		Codec.xAPI.config.set(`Video Input Connector ${Codec.ConnectorId} Visibility`, 'Always');
		break;
	  case 'OUTOFCALL':
		Codec.xAPI.config.set('UserInterface Features Share Start','Hidden');
		Codec.xAPI.config.set(`Video Input Connector ${Codec.HDCPCapableConnectorId} HDCP Mode`,((Codec.HDCPEnabledByConfiguration) ? 'On':'Off'));
		SignalStates_on_AllocatedConnectorIds.map( c => Codec.xAPI.config.set(`Video Input Connector ${c.ConnectorId} Visibility`, 'Never'));
		break;
	  default: break;
	}
}

function CloseVideoSignalNotifier() {
	clearTimeout(SourceNotifier);
	clearTimeout(ExitPresentationNotifier);
	clearTimeout(ExitPresentationTimer);
}

function USBConnectedStateChanged(portNumber, state){
	for (var cam in WebcamSources) {
		if (portNumber == (parseInt(cam) + 1)) {
			if(typeof(WebcamSources[cam]) != "undefined"){
				if(/true|1/.test(state)){
					Codec.xAPI.command('UserInterface Message Prompt Display',{
						Title:WebcamSources[cam]+' USB plugged in',
						Text:'Do you want to switch webcam to '+WebcamSources[cam]+'?',
						'Option.1':'Yes',
						'Option.2':'No',
						FeedbackId:'SwitchWebcam'+WebcamSources[cam]
					});
				}
				else{
					let prevSelCamPres = parseInt(PreviousSelectedCameraPreset, 10);

					if(!isNaN(prevSelCamPres) && prevSelCamPres === portNumber){
						Codec.xAPI.command('UserInterface Extensions Widget Action', {Type:'pressed', WidgetId: 'webcamselector', Value:'Webex'});
					}
				}
			}
			
		}
	}
}

function errorCodec(err) {
	Codec.isConnected = false;
	console.log('  == > Cisco Codec conenction issue with:',err);
	
	clearInterval(Shared.HeartBeat);
	try {
		if (Codec.xAPI !== null) {
			Codec.xAPI.close();
			Codec.xAPI=null;
		}
	} catch (err) {
		console.log('Err ==> Codec.xAPI.close();',err);
	} finally {
		Codec.xAPI = null;
		clearTimeout(wsconnecttimeout);
		wsconnecttimeout = setTimeout( function()
			{
				jsxapi.connect("wss://"+Codec.IPAddress, {
					username: Codec.UserName,
					password: Codec.Password,
				})
				.on('close', (err) => {errorCodec(err);})
				.on('error', (err) => {errorCodec(err);})
				.on('ready', (xapi) => {
					Codec.xAPI = xapi;
					xapi.backend.isReady.then( (xapi) => {
						readyCodec();
					})
					.catch((reason) => {
						console.log('isReady catched: ',reason);
					});
				});
			},
			1000
		);
	}
}


  
  
  
  
  
