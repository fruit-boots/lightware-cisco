var net = require('net');

/////////////////////////////////////////////////
// LWR3 protocol client JS implementation
/////////////////////////////////////////////////

function wildCompare(string, search){
    // utility function for wildchar comparison
    var prevIndex = -1,
        array = search.split('*'), // Split the search string up in sections.
        result = true;
    for(var i = 0; i < array.length && result; i++){ // For each search section
        var index = string.indexOf(array[i]); // Find the location of the current search section
        if(index == -1 || index < prevIndex){ // If the section isn't found, or it's placed before the previous section...
            return false;
        }
    }
    return result;
}

function escapeLW3ControlChars(message) {
    message = message.toString();

    message = message.replace(/\\r/g, ">>CR<<");
    message = message.replace(/\\n/g, ">>LF<<");
    message = message.replace(/\\t/g, ">>TAB<<");

    message = message.replace(/\r/g, ">>CR<<");
    message = message.replace(/\n/g, ">>LF<<");
    message = message.replace(/\t/g, ">>TAB<<");

    message = message.replace(/([\\{}#%()])/g, "\\$1");

    message = message.replace(/>>CR<</g, String.fromCharCode(92) + String.fromCharCode(114));
    message = message.replace(/>>LF<</g, String.fromCharCode(92) + String.fromCharCode(110));
    message = message.replace(/>>TAB<</g, String.fromCharCode(92) + String.fromCharCode(116));

    return message;
};

function unescapeLW3ControlChars(message) {
    message = message.toString().replace(/\\(\\|\{|\}|#|%|\(|\))/g, "$1");

    message = message.replace(/\\r/g, String.fromCharCode(13));
    message = message.replace(/\\n/g, String.fromCharCode(10));
    message = message.replace(/\\t/g, String.fromCharCode(9));

    return message;
};

class NodeToWatch {
    constructor(client, nodePath, callback){
        this.client = client;
        this.nodePath = nodePath;
        this.callback = callback;
    }
    init() {
        this.client.OPEN(this.nodePath, "*",(x) => {
            this.callback(x.topic, x.payload);
        });
    }
    load() {
        this.client.GET(this.nodePath+'.*', (x) => {
            this.callback(x.topic, x.payload);
        });
    }
};
class PropertyToWatch {
    constructor(client, propertyPath, callback){
        this.client = client;
        this.propertyPath = propertyPath;
        this.callback = callback;
        let pathSplit = propertyPath.split(".");
        this.node = pathSplit[0];
        this.property = pathSplit[1];
    }
    init() {
        this.client.OPEN(this.node, this.property, (x)=>{
            this.callback(x.payload);
        });
    }
    load() {
        this.client.GET(this.propertyPath, (x) => {
            this.callback(x.payload);
        });
    }
}

function Lwr3Client(name, host, port, waitresponses, initialwait, log_enable, callback) {
    this.name = name;
    this.host = host;
    this.port = port;
    this.waitresponses = waitresponses;
    this.cmdtosend = [];
    this.watchers = [];
    this.initialwait = initialwait;
    this.callback = callback;
    this.log_enable = log_enable;
    
    this.connected = false;
    this.connecting = false;         
    this.shutdown = false;
    this.inputbuffer = "";
    this.conn = new net.Socket();
    this.conn.setEncoding('utf8');        
    this.subscribers = [];
    this.connectionListeners = [];
    this.deviceDriver = null;
    this.firstConnect = true;
    this.addNodeWatcher = function(nodePath, callback) {
        let nodeWatcher = new NodeToWatch(this, nodePath, callback);
        this.watchers.push(nodeWatcher);
        if(!this.firstConnect){
            nodeWatcher.init();
            nodeWatcher.load();
        }
    }.bind(this);
    this.addPropertyeWatcher = function(propertyPath, callback) {
        let propertyWatcher = new PropertyToWatch(this, propertyPath, callback);
        this.watchers.push(propertyWatcher);
        if(!this.firstConnect){
            propertyWatcher.init();
            propertyWatcher.load();
        }
    }.bind(this);

    //
    // Connection handling routines
    //

    this.conn.on('connect', function() {
        if(this.log_enable) {
            console.log('LW3 connection established on ' + this.name);
        }
        this.connecting = false;
        this.connected = true;
        subscribed = [];
        this.subscribers.forEach(function(i) {
            if (subscribed.indexOf(i.path) == -1)
                this.cmdsend('OPEN '+i.path, function(){});
            subscribed.push(i.path);        
        }.bind(this));
        if(this.firstConnect) {
            if (this.callback) {
                this.callback();
            }
            this.firstConnect = false;
            for(let w of this.watchers) {
                w.init();
            }
        }
        for(let w of this.watchers) {
            w.load();
        }
        //TODO call connectionListeners when all watchers ar loaded
        for(let l of this.connectionListeners) {
            l(true);
        }
    }.bind(this));
    this.conn.on('close', function() {
        if(this.log_enable) {
            console.log('LW3 connection was closed');
        }
        const lastConnected = this.connected;
        this.connected = false;
        this.deviceDriver = null;
        setTimeout(() => {this.startConnect()}, 1000);
        if(lastConnected) { //only call callbacks, if connected went down (skip when closing already closed client)
            for(let l of this.connectionListeners) {
                l(false);
            }
        }
    }.bind(this));
    this.conn.on('error', function(e) {
        if (this.connecting) {
            if(this.log_enable) {
                console.log('LW3 connection error:' + e.toString());
            }
        }            
    }.bind(this));
    this.startConnect = function() {
        if (!this.shutdown) {
            this.connecting = true;
            this.connected = false;
            this.conn.connect(this.port, this.host);
        }
    }.bind(this);

    this.startConnect();

    //
    //Incoming buffer handling routines
    //

    this.conn.on('data', function(data) {
        // collecting incoming data into a single buffer and splitting into lines        
        if (data instanceof ArrayBuffer) {
            data = String.fromCharCode.apply(null, new Uint8Array(data));
        }        
        this.inputbuffer += data;
        let lines = this.inputbuffer.split(/[\r\n]+/);
        if (lines.length > 1) {
            this.inputbuffer = lines[lines.length-1];
            lines.pop();
            lines.forEach(data => {this.linercv(data)});
        }
        if (this.inputbuffer.length > 10e3) {
            this.inputbuffer = '';
            console.log('Received data has contained a line with more than 10kbyte data. Maybe it is not LW3 protocol?');
        }
    }.bind(this));

    this.inblock = false;
    this.block = [];
    this.signature = '';
    this.linercv = function(data) {
        if (this.log_enable)
            console.log(this.name + ' << '+data);
        // a new line has been received.        
        if (!data.length) return;        
        if (data.search('CHG ') === 0)
            this.chgrcv(data);
        else if (!this.inblock) {
            if (data.charAt(0) == '{') {
                this.inblock = true;
                this.signature = data.substring(1,5);
            } else {
                console.log('Some strange thing has arrived: '+data);
            }
        } else if (data.charAt(0) == '}') {
            this.blockrcv(this.signature, this.block);
            this.block=[];
            this.inblock = false;
        } else {
            this.block.push(data);
        }
    }.bind(this);
    this.addConnectionListener = function(listener) {
        this.connectionListeners.push(listener);
    }.bind(this);

    this.chgrcv = function(data) {
        data = unescapeLW3ControlChars(data);
        //a new CHG message has been received        
        data = data.substring(4, data.length);
        eq = data.search('=');
        if (eq == -1) {
            console.log('Strange message: '+data);
            return;
        }
        proppath = data.substring(0,eq);
        nodepath = proppath.substring(0,proppath.indexOf('.'));
        propname = proppath.substring(proppath.indexOf('.')+1, proppath.length);            
        value = data.substring(eq+1, data.length);
        this.subscribers.forEach(function(i){
            if (i.path == nodepath) {
                payload = this.convertValue(value);
                if ((i.property === '') || (i.property == propname)) {
                    if ((i.value == '') || (i.value == payload))
                        i.callback({'topic':propname, 'path':nodepath, 'payload':payload, 'name':this.name});
                } else if (i.property.indexOf('*') != -1) {
                    if (wildCompare(propname, i.property))
                        if ((i.value == '') || (i.value == payload))
                            i.callback({'topic':propname, 'path':nodepath, 'payload':payload, 'name':this.name});
                }
            }
        }.bind(this));
    };

    this.convertValue = function(value) {
        if (Number.isSafeInteger(value))
            value = parseInt(value);
        else if (value.toUpperCase() == 'FALSE')
            value = false;
        else if (value.toUpperCase() == 'TRUE')
            value = true;
        else if (value.indexOf(';') != -1) {
            value = value.split(';');
            if (value.slice(-1)[0] === '')   //remove last item if empty
                value.pop();
        }
        return value;
    }.bind(this);

    this.waitlist = [];
    this.blockrcv = function(signature, data) {
        //a new block of lines have been arrived                        
        for (let i=0; i<this.waitlist.length; i++) if (this.waitlist[i].sign == signature) {
            const tmp = this.waitlist[i];
            this.waitlist.splice(i, 1);
            if (this.waitresponses)
                if (this.cmdtosend.length > 0) {
                    const data2send = this.cmdtosend.shift();
                    this.conn.write(data2send);
                    if (this.log_enable)
                        console.log(this.name + ' >> '+data2send);
                }
            if (tmp.info !== undefined)
                tmp.callb(data, tmp.info);
            else
                tmp.callb(data);            
            return;
        } 
        console.log('Unexpected response with signature: '+signature);
    }.bind(this);

    //
    // Outgoing buffer handler
    //

    this.signature_counter = 0;
    this.cmdsend = function(cmd, callback, callback_info) {                
        if (!this.connected) return;        
        signature = ((this.signature_counter+0x10000).toString(16).substr(-4).toUpperCase());
        data = signature + '#' + cmd + '\n';
        
        if (!this.waitresponses) {
            this.conn.write(data);
            if (this.log_enable)
                console.log(this.name + ' >> '+data);
        } else if (this.waitlist.length == 0) {
            //
        } else {
            this.cmdtosend.push(data);
        }

        
        callback_info = callback_info || undefined;
        this.waitlist.push({'sign': signature, 'callb': callback, 'info':callback_info});
        this.signature_counter = (this.signature_counter + 1) % 0x10000;
        //todo timeout?
    }.bind(this);

    //
        // LW3 commands and response handlers
        //

        this.SET = function(property, value, callback) {
            value = escapeLW3ControlChars(value);
            //todo sanity check
            this.cmdsend('SET '+property+'='+(value.toString()), function(data){
                data = unescapeLW3ControlChars(data);
                callback({success: data.charAt(1) != 'E', resp: data});
            });
        }.bind(this);

        this.CALL = function(property, value, callback) {
            value = escapeLW3ControlChars(value);
            //todo sanity check
            if (callback === null) return;
            this.cmdsend('CALL '+property+'('+value+')', function(data) {
                data = unescapeLW3ControlChars(data);
                callback({success: data.charAt(1) != 'E', resp: data});
            });
        }.bind(this);
        this.GETALL = function(nodepath, callback) {
            if (callback === null) return;
            this.cmdsend("GETALL "+nodepath, function(data, property)  {
                callback(data.map((value) => {
                    value = unescapeLW3ControlChars(value);
                    const afterPath = value.split(nodepath)[1];
                    return {
                        attribute: value.split(' ')[0],
                        value: afterPath.split('=')[1],
                        name: afterPath.substring(1).split('=')[0],
                    };
                }));
            });
        }.bind(this);


        this.GET = function(property, callback) {
            /* Getting a single or multiple property 
                Path can contain multiple wildchars even in path and propertyname
            */
            //todo sanity check
            if (callback === null) return;
            device = this;

            path = property.split('.');
            if (path.length != 2) {
                console.log("Getting invalid property: "+property);
                return;
            }            

            if (path[0].indexOf("*") == -1) {
                //path contains no wildchar charachter - getting properties.
                command = 'GET '+property;
                if (path[1].indexOf('*') != -1) command = 'GET '+path[0]+'.*'; //if property name contains wildchar, we should search for *                
                this.cmdsend(command, function(data, property)  {
                    path = property.split('.');                    
                    data.forEach(function(data) {
                        data = unescapeLW3ControlChars(data);
                        if (data.charAt(0) != 'p') return;                    //skip methods                        
                        if (data.indexOf(path[0]) == -1) return;              //malformed answer?                        
                        n = data.indexOf('=');                                                
                        if (n==-1) return;                                    //malformed answer?                        

                        response_property = data.split('.')[1].split('=')[0];
                        
                        if (wildCompare(response_property, path[1])) {
                            callback({'payload':device.convertValue(data.substring(n+1, data.length)),
                                      'topic':response_property,
                                      'path':path[0],
                                      'name':this.name});
                        }
                    });
                }, property);
            } else {
                //path contain wildchar charachters. We need find the required subnodes.
                path_parts = path[0].split("/");
                w_id = -1;
                for (i=0; i<path_parts.length; i++) if (path_parts[i].indexOf("*") != -1) { w_id = i; break; }                
                new_path = path_parts.slice(0, w_id).join("/");

                this.cmdsend('GET '+new_path, function(data, param) {
                    path_parts_local = param[0];
                    w_id_local = param[1];
                    callback_local = param[2];
                    data.forEach(function(item) {
                        item = unescapeLW3ControlChars(item);
                        if (item.indexOf('n- ') != 0) return;
                        response_path = item.split(' ')[1];
                        if (wildCompare(response_path.split('/').slice(-1)[0], path_parts_local[w_id_local])) {
                            str = response_path+'/'+path_parts_local.slice(w_id_local+1).join('/');
                            device.GET(str+'.'+path[1], callback_local);
                        }
                    });
                }.bind(this), [path_parts.slice(), w_id, callback]);
            }
        }.bind(this);

        this.GETNODES = function(path, callback) {
            this.cmdsend("GET "+path, function(data, path)  {
                for (var i=0;i<data.length;i++) data[i] = data[i].replace('n- ','').replace(path,'').replace('/','');
                callback(data);
            }.bind(this), path);
        }.bind(this);


        this.OPEN = function(path, property, callback) {
            if (callback === null) return;
            //todo sanity check
            if (path.indexOf('*') == -1) {  //path has no wildchar
                alreadyOpen = false;
                for (i=0; i<this.subscribers.length; i++) if (this.subscribers[i].path == path) alreadyOpen=true;
                if (!alreadyOpen) {
                    this.cmdsend('OPEN '+path, function(data){
                        try {
                            if (data[0].charAt(0) != 'o') throw 0;
                            if (data[0].search(path) === -1) throw 0;
                        } catch (err) {
                            console.log('Subscribing to node '+path+' was unsuccesful.');                        
                        }
                    });
                }
                if (property.indexOf('=') != -1) {
                    propval = property.split('=')[1];
                    propname = property.split('=')[0];      
                } else {
                    propname = property;
                    propval = '';
                }
                this.subscribers.push({'path': path,
                                       'property': propname,
                                       'value': propval,
                                       'callback': callback});
            } else {    //there are one or more wildchar in path, the tree must be discoveried
                path_parts = path.split("/");
                w_id = -1;
                for (i=0; i<path_parts.length; i++) if (path_parts[i].indexOf("*") != -1) { w_id = i; break; }                
                new_path = path_parts.slice(0, w_id).join("/");

                this.cmdsend('GET '+new_path, function(data, param) {
                    path_parts_local = param[0];
                    w_id_local = param[1];
                    property_local = param[2];
                    callback_local = param[3];
                    data.forEach(function(item) {                        
                        if (item.indexOf('n- ') != 0) return;
                        response_path = item.split(' ')[1];
                        if (wildCompare(response_path.split('/').slice(-1)[0], path_parts_local[w_id_local])) {
                            str = response_path+'/'+path_parts_local.slice(w_id_local+1).join('/');
                            device.OPEN(str, property_local, callback_local);
                        }
                    });                    
                }, [path_parts.slice(), w_id, property, callback]);
            }
        }.bind(this);

        this.removeListener = function(cb) {
            this.subscribers = this.subscribers.filter(function(item) { return (item.callback) !== (cb.callback); });
        }.bind(this);
        return this;
}

/////////////////////////////////////////
// LW3 Noodle-like interface
////////////////////////////////////////

function wrapNode(object){
    // Converts the given dictionary into a function, thus we can create apply proxy around it
    func = function(){};
    for(var prop in object){
        if(object.hasOwnProperty(prop)){
            func[prop] = object[prop];
        }
    }
    return func;
}

var NoodleProxyHandler = {
    apply: async function(target, ctx, args) {
        last = target.path[target.path.length-1];
        pth = '/'+target.path.slice(0,-1).join('/')
        if (last == 'addListener') {            
            target.lw3.OPEN(pth, args[0], (n)=>{args[1](n.name+':'+n.path+'.'+n.topic, n.payload);});
        } else if (last == 'once') {
            target.lw3.OPEN(pth, args[0], function(n) {target.lw3.removeListener(this); args[1](n.name+':'+n.path+'.'+n.topic, n.payload);});
        } else if (last == 'waitFor') {
            //creating a promise
            return new Promise(function(resolve, reject){
                target.lw3.OPEN(pth, args[0], function(n) {target.lw3.removeListener(this); resolve();});
            });
        } else {
            //method invocation            
            return new Promise((resolve, reject) => target.lw3.CALL(pth+':'+last, args.join(','), resolve));
        }
    },

    get: function(target, key) {                
        if (((key == key.toUpperCase()) || (key[0] == key[0].toLowerCase()) || (key.indexOf('__method__')!=-1) || (key.indexOf('__node__')!=-1)) && (key.indexOf('__prop__') == -1)) {  // node or method
            key = key.replace('__method__','').replace('__node__','');
            node = wrapNode(target);
            node.path = target.path.slice().concat(key);
            return new Proxy(wrapNode(node), NoodleProxyHandler);
        } else { // should be a property
            key = key.replace('__prop__','');
            path = '/'+target.path.join('/');                       
            return new Promise((resolve, reject) => {target.lw3.GET(path+'.'+key, (x) => {resolve(x.payload)})});
        }        
    },

    set: function(target, key, value) {      
            key = key.replace('__prop__','');
            path = '/'+target.path.join('/');
            target.lw3.SET(path+'.'+key, value, () => {});
            return true;
    }          
};

exports.Noodle = (conn, callback) => {
    conn.port = conn.port||6107;
    conn.host = conn.host||'127.0.0.1';      
    conn.name = conn.name||'default';
    conn.initialwait = conn.initialwait||0;
    conn.waitresponses = conn.waitresponses||false;
    conn.log = conn.log||false;
    conn.lw3 = new Lwr3Client(conn.name, conn.host, conn.port, conn.waitresponses, conn.initialwait, conn.log, callback);
    conn.path = [];
    conn.root = new Proxy(conn, NoodleProxyHandler);
    return conn;
}
